% sphere masses (kg)
mA = 10;
mB = 10;
mC = 1000;

% sphere radii (m)
RA = 1;
RB = 1;
RC = 2;

% boundary radius (m)
boundaryR = 4;

% sphere drag coefficient (N/m/s)
cA = 0.1;
cB = 0.1;
cC = 1;

% sphere-sphere contact stiffness (N/m)
k = 100;

% sphere-wall contact stiffness (N/m)
kwall = 100;

% sphere-wall contact damping (N/m/s)
cwall = 0.1;

% Initial position values
xA0 = -5;
yA0 = -5;
xB0 = 5;
yB0 = -5;
xC0 = 0;
yC0 = 0;


% Maximum force applied in x or y direction (N)
maxF = 0.5;

% Sample time (Ts) and simulation time (Tf)
Ts = 0.1;
Tf = 90;

% Environment limits
xLimits = [-12 12];
yLimits = [-12 12];