function plotEnvironment(x,y,R,boundaryR,t)

persistent f
if isempty(f) || ~isvalid(f)
    f = figure(...
        'Toolbar','auto',...
        'NumberTitle','off',...
        'Name','Multi Agent Collaborative Task',...
        'Visible','on'); %,...
        %'MenuBar','none');
    ha = gca(f);
    axis(ha,'equal');
    ha.XLim = [-12 12];
    ha.YLim = [-12 12];
    ha.Box = 'on';
    xlabel(ha,'X (m)');
    ylabel(ha,'Y (m)');
    
    D = [-1 -1 2 2]*boundaryR;
    rectangle(ha,'Position',D,'Curvature',[1 1]);
    
    hold(ha,'on');
end

% plot elements
ha = gca(f);
N = numel(R);
colors = ["r","g","b"];
for i = 1:N
    D = [(x(i)-R(i)) (y(i)-R(i)) 2*R(i) 2*R(i)];
    tagstr = sprintf('rect_%u',i);
    r = findobj(ha,'Tag',tagstr);
    if isempty(r)
        r = rectangle(ha,'Position',D,'Curvature',[1 1],'Tag',tagstr);
        r.FaceColor = colors(i);
    else
        r.Position = D;
    end
end

% Display time string
timestr = sprintf('Time: %0.1f s',t);
time = findobj(ha,'Tag','time');
if isempty(time)
    text(ha,5,10,timestr,'Tag','time');
else
    time.String = timestr;
end

end